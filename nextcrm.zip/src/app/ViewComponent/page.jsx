import ViewComponent from '@/Components/ViewComponent'
import React from 'react'

function page() {
  return (
    <div>
      <ViewComponent/>
    </div>
  )
}

export default page
