import Image from "next/image";
// pages/_app.js or pages/index.js
import '@fortawesome/fontawesome-free/css/all.min.css';



export default function Home() {
  return (
    <>
      
    </>
  );
}
