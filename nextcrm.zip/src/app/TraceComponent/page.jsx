import TraceComponent from '@/Components/TraceComponent'
import React from 'react'

function page() {
  return (
    <div>
      <TraceComponent/>
    </div>
  )
}

export default page
