import DialerAgentPerformanceRecord from '@/Components/TLDashboard/DialerAgentPerformanceReport'
import React from 'react'

function page() {
  return (
    <div>
      <DialerAgentPerformanceRecord/>
    </div>
  )
}

export default page
