// import TLDashboard from '@/Components/TLDashboard/Admin'
import React from 'react'

function Admin() {
  return (
    <div>
      {/* <TLDashboard/> */}
    </div>
  )
}

export default Admin
