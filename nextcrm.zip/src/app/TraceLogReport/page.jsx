import TraceLogReport from '@/Components/TLDashboard/TraceLogReport'
import React from 'react'

function page() {
  return (
    <div>
      <TraceLogReport/>
    </div>
  )
}

export default page
