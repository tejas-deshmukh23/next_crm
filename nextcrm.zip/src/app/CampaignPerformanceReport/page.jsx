import CampaignPerformanceReport from '@/Components/TLDashboard/CampaignPerformanceReport'
import React from 'react'

function page() {
  return (
    <div>
        <CampaignPerformanceReport/>
      
    </div>
  )
}

export default page
