import LoginPage from '@/Components/LoginPage/Login'
import React from 'react'
import TableComponent from "../../Components//TableComponent";

function page() {
  return (
    <div>
      <LoginPage/>
      {/* <TableComponent/> */}
    </div>
  )
}

export default page
